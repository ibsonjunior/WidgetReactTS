import { Widget } from "./Components/Widget"


export const App = () => {
 

  return <Widget />
        
 
}

// Componente é uma função que retorna html, jsx (Typescript + xml)
// Propriedades = atributo do html
// Rederizar = mostra em tela 
